package Main.Controllers;
/**
 * <h6>Edit Appointment</h6>
 * <p>The class provides functionality for the editing appointments
 *</p>
 * */
import Main.Models.*;
import Main.Scheduler;
import Main.Utilities.Helpers.Formatter;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Timestamp;
import java.time.*;
import java.util.Date;
import java.util.ResourceBundle;

public class EditAppointmentController implements Initializable {
    Stage stage;
    Parent scene;

    @FXML
    private Label idLabel;
    @FXML
    private TextField appointmentIdTextBox;
    @FXML
    private TextField titleTextBox;
    @FXML
    private TextField locationTextBox;
    @FXML
    private TextField typeTextBox;
    @FXML
    private TextArea descriptionTextArea;
    @FXML
    private ComboBox customerIdDropDown;
    @FXML
    private ComboBox contactIdDropDown;
    @FXML
    private TextField userIdTextBox;
    @FXML
    private TextField startTimeTextBox;
    @FXML
    private TextField endTimeTextBox;
    @FXML
    private DatePicker datePicker;
    @FXML
    private Label businessHoursLabel;

    Database db = new Database();


    /** To Main Menu if Cancelled**/
    public void toMainMenu(ActionEvent event) throws IOException {
        stage = (Stage) ((Button)(event.getSource())).getScene().getWindow();
        scene = FXMLLoader.load(Scheduler.class.getResource("AppointmentView.fxml"));
        stage.setScene(new Scene(scene));
        stage.show();
    }

    /**Save Part */
    @FXML
    public void saveAppointment( ActionEvent event) throws IOException {
        try {
            /**Convert input fields into correct types*/

            int  id = Integer.parseInt(appointmentIdTextBox.getText());
            String title = titleTextBox.getText();
            String location =  locationTextBox.getText();
            String type = typeTextBox.getText();
            String description = descriptionTextArea.getText();
            String[] arrayOfStr = customerIdDropDown.getValue().toString().split(" ", 2);
            int customerId =  Integer.parseInt(arrayOfStr[0]);
            String[] contacts = contactIdDropDown.getValue().toString().split(" ", 2);
            int contactID =  Integer.parseInt(contacts[0]);
            LocalDate date =  datePicker.getValue();
            LocalDateTime startTime = LocalTime.parse(startTimeTextBox.getText()).atDate(date) ;
            LocalDateTime endTime = LocalTime.parse(endTimeTextBox.getText()).atDate(date) ;

            ZonedDateTime startHours = ZonedDateTime.parse(date + "T08:00:00-04:00[America/New_York]");
            ZonedDateTime endHours = ZonedDateTime.parse(date + "T22:00:00-04:00[America/New_York]");

            LocalDateTime startBusiness = startHours.withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime();
            LocalDateTime endBusiness = endHours.withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime();

            //Check the dates
            if(endTime.isBefore(startTime)){
                throw new Exception("End time must be after start time");
            }

            if(startTime.isBefore(startBusiness) || endTime.isAfter(endBusiness)){
                throw new Exception("Appointment must be within business hours " + startBusiness + "-" + endBusiness);
            }


            Formatter format = new Formatter();
            Timestamp startTS =  format.localToSqlTimestamp(startTime.toLocalTime(),date);
            Timestamp endTS = format.localToSqlTimestamp(endTime.toLocalTime(),date);


            if (title.length() != 0  && description.length()  != 0 && type.length()  != 0  && startTime.toString().length()  != 0 && endTime.toString().length()  != 0) {


                Appointment appointment = new Appointment(id, title, description, location,
                        type, startTS, endTS, customerId, SessionLog.getLoggedOnUser(), contactID);
                Database db = new Database();
                String result = db.editAppointment(appointment);
                stage = (Stage) ((Button)(event.getSource())).getScene().getWindow();
                scene = FXMLLoader.load(Scheduler.class.getResource("AppointmentView.fxml"));
                stage.setScene(new Scene(scene));
                stage.show();
            }else{
                throw new Exception("Fields Can't be left blank");
            }
            /**If there is any error we catch is and print it out*/
        } catch (Exception e) {
            Alert invalidEntryAlert = new Alert(Alert.AlertType.ERROR);
            invalidEntryAlert.setTitle("Error");
            invalidEntryAlert.setHeaderText(e.toString());
            invalidEntryAlert.show();
            e.printStackTrace();
        }
    }

    public void getAppointment(Appointment appointment) {
        /**
         * Get and Set each form field to reflect corresponding data of part Object
         */
       appointmentIdTextBox.setText(String.valueOf(appointment.getAppointmentId()));;;
       appointmentIdTextBox.setEditable(false);;
       titleTextBox.setText(appointment.getTitle());
       locationTextBox.setText(appointment.getLocation());
       typeTextBox.setText(appointment.getType());
       descriptionTextArea.setText(appointment.getDescription());
       customerIdDropDown.setValue(appointment.getCustomerID());
       contactIdDropDown.setValue(appointment.getContactID());
       startTimeTextBox.setText(appointment.getStartTime().toLocalDateTime().toLocalTime().toString());
       endTimeTextBox.setText(appointment.getEndTime().toLocalDateTime().toLocalTime().toString());
       datePicker.setValue(appointment.getDate());
    }

    public  void initialize(URL url, ResourceBundle rb){
        //Prep business hours
        ZonedDateTime startHours = ZonedDateTime.parse("2022-01-01T08:00:00-05:00[America/New_York]");
        ZonedDateTime endHours = ZonedDateTime.parse("2022-01-01T22:00:00-05:00[America/New_York]");

        String startBusiness = String.valueOf(startHours.withZoneSameInstant(ZoneId.systemDefault()).getHour());;
        String endBusiness = String.valueOf(endHours.withZoneSameInstant(ZoneId.systemDefault()).getHour());
        businessHoursLabel.setText(startBusiness.toString() + ":00 -" + endBusiness + ":00 " + ZoneId.systemDefault().toString());

        Database db = new Database();
        int user = SessionLog.getLoggedOnUser();
        idLabel.setText(String.valueOf(user));
        customerIdDropDown.setItems(db.getCustomersIds());
        contactIdDropDown.setItems(db.getContactIds());
    }
}
