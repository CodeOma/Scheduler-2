•  title and purpose of the application
C195 Appointment Scheduler.
Users can create, delete and edit customers and appointments.

•  author, contact information, student application version, and date
Author: Omar Ahmed
Contact information: oahme10@wgu.edu
Version: 1.0
Date: March 2

•  IDE including version number (e.g., IntelliJ Community 2020.01), full JDK of version used (e.g., Java SE 17.0.1),
   and JavaFX version compatible with JDK version (e.g. JavaFX-SDK-17.0.1)
   IntelliJ 2021.2.3 Community Edition.
   JavaFx SDK 11


•  directions for how to run the program
    Sign in using user and password of test & test or admin/admin.
    If you have any appointments upcoming within 15 minutes you will receive a notificaiton.
    You can continue to create, edit, delete customer by clicking the customer button.
    You can create, edit, delete appointments by clicking the Appointments button.
    You can check out the different reports under reports button.


•  a description of the additional report of your choice you ran in part A3f
    Additional report gives you the total number of successful and unsuccessful login attempts.

•  the MySQL Connector driver version number, including the update number (e.g., mysql-connector-java-8.1.23)
 mysql-connector-java-8.0.27